class Hello {
    void main() {
        int a;
        a = 0;

        a += 2;
        print(a);

        a++;
        print(a);
    }
}

