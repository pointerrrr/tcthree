class Hello {
    void main() {
        print(3 * 5 + 2);

        print(3 + 2 == 1);
    }
}

