class Hello {
    void main() {
        printadd(2, 3);
    }

    void printadd(int a, int b) {
        print(a + b);
    }
}
