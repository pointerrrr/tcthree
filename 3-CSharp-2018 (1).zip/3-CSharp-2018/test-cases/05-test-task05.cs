class Hello {
    void main() {
        print(five());
    }

    int five() {
        return 5;
    }
}
