class Hello
{
    // int g;
    
    void main()
    {
        // int r;
        // r = 1;
        
        // for (int x; x<5; x = x + 1;)
        // {
        //   r = r+5;
        // }
    }
    
    int square( int x )
    {
        x = x*x;
        return x;   
    }

    int abs(int x)
    {
    	
        if (x<0)
            x = 0-x;
        return x;
    }
    bool bbb()
    {
        return true || false;
    }
    
   //  int fac(int x)
   //  {
   //      int r; int t;
   //      t=1; r=1;
   //      while (t<=x)
   //      {
   //          r = r*t;
   //          t = t+1;
   //      }
   //      return r;
   // }
}
