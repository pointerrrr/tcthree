Assingment 3-CSharp-2018, 
made by: 
  - Lennart Van Koot 5923395
  - Mathan Geurtsen  5896347
  
Assignments made: 
  - 1 through to 10
  - for bonus we added an error for undeclared variables

added a testfile `testfile.cs` that should test all our code. 
