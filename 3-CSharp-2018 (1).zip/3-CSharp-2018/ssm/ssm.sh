#! /bin/sh
java -jar ssmui.jar $@
