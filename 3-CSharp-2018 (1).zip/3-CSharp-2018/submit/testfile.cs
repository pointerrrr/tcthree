class Test
{
    // Comments aren't read
    
    void main()
    {
        int r; int s;

        r = s = 2;
        s = square(r);
        s = abs(r);
        s = fac(r);

        bool b;
        b = lazyEvaluation();

        for (int x;x = 0; x<5; x = x + 1;)
        {
          r = r+5;
        }

        print(r + 3);
    }
    
    int square( int x )
    {
        x = x*x;
        return x;   
    }

    int abs( int x )
    {
    	
        if (x<0)
            x = 0-x;
        return x;
    }

    bool lazyEvaluation()
    {
        return true || false;
    }
    
    int fac( int x )
    {
        int r; int t;
        t=1; r=1;
        while (t<=x)
        {
            r = r*t;
            t = t+1;
        }
        return r;
    }
}
