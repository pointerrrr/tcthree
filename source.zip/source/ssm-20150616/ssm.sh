#!/bin/sh
java -jar ssm.jar $*
#java -jar /Volumes/Work/Programming/staff.atze.ssm/build/ssm.jar $*
#java -cp ssmui.jar nl.uu.cs.ssmui.Runner $*
