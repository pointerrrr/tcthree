//comment
class Hello
{
    int g;
    //comment
    void main()
    {
        /*comment
        multiline*/
        print(true || false);
    }

    int threeArg(int x, int y, int z)
    {
      return x + y + z;
    }

    int square( int x )
    {
        int y;
        y = x*x;
        return y;
    }

    int one()
    {
      return 16;
    }

    int abs(int x)
    {

        if (x<0)
            x = 0-x;
        return x;
    }

    int fac(int x)
    {
        int r; int t;
        t=1; r=1;
        while (t<=x)
        {
            r = r*t;
            t = t+1;
        }
        return r;
   }
}
