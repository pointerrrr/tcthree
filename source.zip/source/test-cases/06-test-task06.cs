class Hello {
    void main() {
        int x;
        x = 5;

        anotherXisTwo();

        print(x * x);
    }

    void anotherXisTwo() {
        int x;
        x = 2;
        print(x);
    }
}

