class Hello {
    void main() {
        print(2 + 3);

        print('a');

        print(true && true);
        print(false && true);
        print(true || false);
        print(false || false);
    }
}
