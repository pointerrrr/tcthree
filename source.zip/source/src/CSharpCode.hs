module CSharpCode where

import Prelude hiding (LT, GT, EQ)
import Data.Map as Map hiding (map, foldl, foldr, filter)
import CSharpLex
import CSharpGram
import CSharpAlgebra
import SSM
import Data.Char

data ValueOrAddress = Value | Address
    deriving Show

type Env = Map String Int

type RTStat = Env -> (Code, Env)
type RTExpr = Env -> ValueOrAddress -> Code

codeAlgebra :: CSharpAlgebra Code Code RTStat RTExpr
codeAlgebra =
    ( fClas
    , (fMembDecl, fMembMeth)
    , (fStatDecl, fStatExpr, fStatIf, fStatWhile, fStatReturn, fStatBlock)
    , (fExprCon, fExprVar, fExprOp, fExprCall)
    )

fClas :: Token -> [Code] -> Code
fClas c ms = [Bsr "main", HALT] ++ concat ms

fMembDecl :: Decl -> Code
fMembDecl d = []

--Makes the env of the declerations in the header of the method. Opens and closes the method
fMembMeth :: Type -> Token -> [Decl] -> RTStat -> Code
fMembMeth t (LowerId x) ps s = [LABEL x, LINK k] ++ code ++ [UNLINK, STS (-n), AJS(-n + 1), RET]
  where n = length ps
        k = size nEnv - n
        (code, nEnv) = s env
        env = fromList $ zip (map (\(Decl _ (LowerId k)) -> k) ps) [-1 - length ps .. -1]

--A decleration adds a new variable in the environment
fStatDecl :: Decl -> RTStat
fStatDecl (Decl _ (LowerId k)) env = ([], insert k index env)
  where index | Map.null env = 1      --if the environment is empty, than this is the first local variable
              | mVal > 0 = mVal + 1   --if there is a local variable all ready, than this variable will become on higher than the latest variable
              | otherwise = 1         --if there were variables, but just no local ones, this becomes the first local variable
        mVal = maximum $ elems env --get the highest relative position to the markpointer

fStatExpr :: RTExpr -> RTStat
fStatExpr e env = (e env Value ++ [pop], env)

fStatIf :: RTExpr -> RTStat -> RTStat -> RTStat
fStatIf e s1 s2 env = (e env Value ++ [BRF (n1 + 2)] ++ code1 ++ [BRA n2] ++ code2, nEnv2)
    where
        (code1, nEnv1)      = s1 env
        (code2, nEnv2)      = s2 nEnv1
        (n1, n2) = (codeSize code1, codeSize code2)

fStatWhile :: RTExpr -> RTStat -> RTStat
fStatWhile e s1 env = ([BRA n] ++ code1 ++ con ++ [BRT (-(n + k + 2))], nEnv)
    where
        con = e env Value
        (code1, nEnv) = s1 env
        (n, k) = (codeSize code1, codeSize con)

--Return puts the evaluation of the expression in the returnregister, and closes the method
fStatReturn :: RTExpr -> RTStat
fStatReturn e env = (e env Value ++ [STR RR, UNLINK, STS (-n), AJS(-n + 1), RET], env)
  where n = length $ filter (< 0) (elems env)

--In a block we need to combine all the code, and the env has to be passed on from statement to statement
fStatBlock :: [RTStat] -> RTStat
fStatBlock ss env = foldl (\(code, nEnv) s -> concat' code (s nEnv)) ([], env) ss
  where concat' c (c1, e) = (c ++ c1, e)

fExprCon :: Token -> RTExpr
fExprCon (ConstInt n) env va  = [LDC n]
fExprCon (ConstBool b) env va = [LDC $ boolInt b]
fExprCon (ConstChar c) env va = [LDC $ ord c]

--True in SSM is defined as -1
boolInt :: Bool -> Int
boolInt True = -1
boolInt False = 0

--Searches for the variable in the env, if it's not known than it's throws a exception
fExprVar :: Token -> RTExpr
fExprVar (LowerId x) env va = case va of
                                  Value    ->  [LDL  loc]
                                  Address  ->  [LDLA loc]
    where loc | member x env = env ! x
              | otherwise = error ("The variable \'" ++ x ++ "\' is not known in the current context")

fExprOp :: Token -> RTExpr -> RTExpr -> RTExpr
fExprOp (Operator "=") e1 e2 env va = e2 env Value ++ [LDS 0] ++ e1 env Address ++ [STA 0]
fExprOp (Operator op)  e1 e2 env va = case op of
                                           --Lazy evaluation of logical operators, first boolean has to be loaded twice,
                                           --since BRF (or BRT) removes the top element on the stack. (XOR can't be evaluated lazily)
                                           "||" -> eval1 ++ eval1 ++ [BRT (n + 1)] ++ eval2 ++ [OR]
                                           "&&" -> eval1 ++ eval1 ++ [BRF (n + 1)] ++ eval2 ++ [AND]
                                           _    -> eval1 ++ eval2 ++ [opCodes ! op]
  where (eval1, eval2) = (e1 env Value, e2 env Value)
        n = codeSize eval2

--After the call the return register is loaded, even if it isn't used, because a expression must leave a result on the stack
fExprCall :: Token -> [RTExpr] -> RTExpr
fExprCall (LowerId "print") es env va = concatMap (\f -> f env va) es ++ replicate (length es) (TRAP 0) ++ [LDR RR]
fExprCall (LowerId x) es env va = concatMap (\f -> f env va) es ++ [Bsr x] ++ [LDR RR]

opCodes :: Map String Instr
opCodes = fromList [ ("+", ADD), ("-", SUB),  ("*", MUL), ("/", DIV), ("%", MOD)
                   , ("<=", LE), (">=", GE),  ("<", LT),  (">", GT),  ("==", EQ)
                   , ("!=", NE), ("&&", AND), ("||", OR), ("^", XOR)
                   ]
