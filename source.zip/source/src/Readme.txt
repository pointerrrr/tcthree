Mart van Saane, 5913993

Extra's:
  -Task 8: Added discarding of comments
  -Task 12: Added lazy evaluation of logical operators (xor can't be evaluated lazy)
  -(Task 14): Added a error message when a undeclared variable is used
