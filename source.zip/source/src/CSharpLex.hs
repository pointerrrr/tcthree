module CSharpLex where

import Prelude hiding ((<$), (<*), (*>))
import Data.Char
import Control.Monad
import ParseLib.Abstract


data Token = POpen    | PClose      -- parentheses     ()
           | SOpen    | SClose      -- square brackets []
           | COpen    | CClose      -- curly braces    {}
           | Comma    | Semicolon
           | KeyIf    | KeyElse
           | KeyWhile | KeyReturn
           | KeyTry   | KeyCatch
           | KeyClass | KeyVoid
           | StdType   String       -- the 8 standard types
           | Operator  String       -- the 15 operators
           | UpperId   String       -- uppercase identifiers
           | LowerId   String       -- lowercase identifiers
           | ConstInt  Int
           | ConstBool Bool
           | ConstChar Char         -- assignment 1
           deriving (Eq, Show)

keyword :: String -> Parser Char String
keyword [] = succeed ""
keyword xs@(x:_) | isLetter x = do ys <- greedy (satisfy isAlphaNum)
                                   guard (xs == ys)
                                   return ys
                 | otherwise  = token xs


greedyChoice :: [Parser s a] -> Parser s a
greedyChoice = foldr (<<|>) empty


terminals :: [(Token, String)]
terminals =
    [ ( POpen     , "("      )
    , ( PClose    , ")"      )
    , ( SOpen     , "["      )
    , ( SClose    , "]"      )
    , ( COpen     , "{"      )
    , ( CClose    , "}"      )
    , ( Comma     , ","      )
    , ( Semicolon , ";"      )
    , ( KeyIf     , "if"     )
    , ( KeyElse   , "else"   )
    , ( KeyWhile  , "while"  )
    , ( KeyReturn , "return" )
    , ( KeyTry    , "try"    )
    , ( KeyCatch  , "catch"  )
    , ( KeyClass  , "class"  )
    , ( KeyVoid   , "void"   )
    ]

--Parsre comments
lexComment :: Parser Char String
lexComment = token "//" <* greedy (satisfy (/= '\n'))   --Single line comments
         <|> token "/*" <* many anySymbol <* token "*/" --Multiline comments

lexWhiteSpace :: Parser Char String
lexWhiteSpace = greedy (satisfy isSpace)

--Combine whitespace lexer with the comment lexer. Both can be ignored
lexWhiteAndComment :: Parser Char String
lexWhiteAndComment = lexWhiteSpace <* greedy (lexComment <* lexWhiteSpace)

lexLowerId :: Parser Char Token
lexLowerId = (\x xs -> LowerId (x:xs)) <$> satisfy isLower <*> greedy (satisfy isAlphaNum)

lexUpperId :: Parser Char Token
lexUpperId = (\x xs -> UpperId (x:xs)) <$> satisfy isUpper <*> greedy (satisfy isAlphaNum)

lexConstInt :: Parser Char Token
lexConstInt = (ConstInt . read) <$> greedy1 (satisfy isDigit)

--Parse keywords true or false
lexConstBool :: Parser Char Token
lexConstBool = ConstBool <$> (True <$ token "true" <|> False <$ token "false")

--Parse a character which must be enclosed in single quotation marks
lexConstChar :: Parser Char Token
lexConstChar = ConstChar <$ symbol '\'' <*> anySymbol <* symbol '\''

lexEnum :: (String -> Token) -> [String] -> Parser Char Token
lexEnum f xs = f <$> choice (map keyword xs)

lexTerminal :: Parser Char Token
lexTerminal = choice [t <$ keyword s | (t,s) <- terminals]


stdTypes :: [String]
stdTypes = ["int", "long", "double", "float", "byte", "short", "bool", "char"]

operators :: [String]
operators = ["+", "-", "*", "/", "%", "&&", "||", "^", "<=", "<", ">=", ">", "==", "!=", "="]


lexToken :: Parser Char Token
lexToken = greedyChoice
             [ lexTerminal
             , lexEnum StdType stdTypes
             , lexEnum Operator operators
             , lexConstInt
             , lexConstBool  --character and bools have to be parsed before lowerid,
             , lexConstChar  --otherwise they will be recognized as that
             , lexLowerId
             , lexUpperId
             ]

lexicalScanner :: Parser Char [Token]
lexicalScanner = lexWhiteAndComment *> greedy (lexToken <* lexWhiteAndComment) <* eof


sStdType :: Parser Token Token
sStdType = satisfy isStdType
    where isStdType (StdType _) = True
          isStdType _           = False

sUpperId :: Parser Token Token
sUpperId = satisfy isUpperId
    where isUpperId (UpperId _) = True
          isUpperId _           = False

sLowerId :: Parser Token Token
sLowerId = satisfy isLowerId
    where isLowerId (LowerId _) = True
          isLowerId _           = False

sConst :: Parser Token Token
sConst  = satisfy isConst
    where isConst (ConstInt  _) = True
          isConst (ConstBool _) = True
          isConst (ConstChar _) = True
          isConst _             = False

--Source grouping operators: https://msdn.microsoft.com/en-us/library/2bxt6kc4.aspx
sMultiplicative :: Parser Token Token
sMultiplicative = satisfy isOperator
    where isOperator (Operator "/") = True
          isOperator (Operator "*") = True
          isOperator (Operator "%") = True
          isOperator _              = False

sAdditive = satisfy isOperator
    where isOperator (Operator "+") = True
          isOperator (Operator "-") = True
          isOperator _              = False

sRelational = satisfy isOperator
    where isOperator (Operator "<")  = True
          isOperator (Operator "<=") = True
          isOperator (Operator ">")  = True
          isOperator (Operator ">=") = True
          isOperator _               = False

sEquality = satisfy isOperator
    where isOperator (Operator "!=") = True
          isOperator (Operator "==") = True
          isOperator _               = False

sBitwiseXOR = satisfy isOperator
    where isOperator (Operator "^") = True
          isOperator _              = False

sLogicalAnd = satisfy isOperator
    where isOperator (Operator "&&") = True
          isOperator _               = False

sLogicalOr = satisfy isOperator
    where isOperator (Operator "||") = True
          isOperator _               = False

sAssignment = satisfy isOperator
    where isOperator (Operator "=") = True
          isOperator _              = False

sSemi :: Parser Token Token
sSemi =  symbol Semicolon
